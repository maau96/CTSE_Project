package com.mapbox.storelocator.util;

/**
 * Class for constant Strings used in the project
 */
public class StringConstants {

  public static final String SELECTED_THEME = "SELECTED THEME";

}
